module com.bazar.sistemabazar {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.kordamp.bootstrapfx.core;
    //requires ObjetosNegocioBazar;
    requires PersistenciaBazar;
    requires ObjetosDTO;

    opens com.bazar.sistemabazar to javafx.fxml;
    exports com.bazar.sistemabazar;
    exports com.bazar.sistemabazar.controllers;
    opens com.bazar.sistemabazar.controllers to javafx.fxml;
    exports com.bazar.sistemabazar.controllers.panels;
    opens com.bazar.sistemabazar.controllers.panels to javafx.fxml;
    exports com.bazar.sistemabazar.controllers.dialogs;
    opens com.bazar.sistemabazar.controllers.dialogs to javafx.fxml;
}