package com.bazar.sistemabazar.controllers.dialogs;

public enum DialogoOperacion {
    LECTURA,
    REGISTRAR,
    ACTUALIZAR,
    ELIMINAR
}
