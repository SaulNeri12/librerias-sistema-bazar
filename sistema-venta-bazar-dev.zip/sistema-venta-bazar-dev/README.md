### Requerimientos

* OpenJDK 18 o superior
* JavaFX 21
* MySQL
* IntelliJ
